# YOYO   [^直播dislike] yoyo
# 有不喜欢的主播？每次在网页看直播都会刷出来？？屏蔽不了？而且还被直播间360了？？？一个chrome 浏览器扩展程序帮助你解决烦恼！！

有不喜欢的主播？ ~~**主播**~~ OUT!!!  XXXXXXX

unlike some of the streamer? ~~**streamer**~~ byebye~



> 使用说明：
>> 1. 支持需要 -- 浏览器
>>> 首先你需要安装谷歌的 [Chrome 浏览器](https://www.google.cn/intl/zh-CN/chrome/)<https://www.google.cn/intl/zh-CN/chrome/>  
如果没有chrome浏览器，请先去官网下载
浏览器安装完成后，在地址栏输入<chrome://extensions>

>>> 1231231
>>2.    使用 <kbd>Ctrl</kbd>+<kbd>Alt</kbd>+<kbd>Del</kbd> 重启电脑




















[^直播dislike]:给斗鱼网页用户提供一款chrome浏览器扩展程序，在页面屏蔽自己不喜欢的主播。
